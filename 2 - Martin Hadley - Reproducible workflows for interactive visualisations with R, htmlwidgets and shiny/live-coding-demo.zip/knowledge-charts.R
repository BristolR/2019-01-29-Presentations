library("tidyverse")

source("audience-knowledge.R", local = TRUE)

gg_barchart <- audience_knowledge %>%
  ggplot(aes(x = question,
             y = response,
             fill = knowledge.type)) +
  geom_col() + 
  coord_flip()

library("plotly")

gg_barchart %>%
  ggplotly()


