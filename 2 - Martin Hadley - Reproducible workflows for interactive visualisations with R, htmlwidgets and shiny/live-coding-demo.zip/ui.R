fluidPage(
  selectInput("exponent",
              "Choose an exponent",
              choices = 1:5),
  plotOutput("curve_plot")
)